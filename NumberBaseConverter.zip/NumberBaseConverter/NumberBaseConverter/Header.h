#include <string>
using namespace std;

string hexToBin(string input);
string decToBin(int input);